var express = require("express");
var app = express();

app.get("/", function(req, res){
    console.log("Home Request Made");
    res.send("Hi there, welcome to my assignment!");
});

var animals = {
    DOG: {
        name: "Dog",
        sound: "Woof Woof!"
    },
    CAT: {
        name: "Cat",
        sound: "Meow!"
    },
    PIG: {
        name: "Pig",
        sound: "Oink Oink!"
    },
    COW: {
        name: "Cow",
        sound: "Moo!"
    },
    SNAKE: {
        name: "Snake",
        sound: "SSSSSSSS"
    }
    
};

app.get("/speak/:animal", function(req, res){
    var animal = req.params.animal.toUpperCase();
    console.log(animal + " request made");
    if(animals[animal] == undefined){
        res.send("Sorry, that animal "+ animal + " was not found.");
    }
    else{
        res.send("The " + animals[animal].name + " goes " + animals[animal].sound);
    }
    });

app.get("/repeat/:word/:number", function(req, res){
    var word = req.params.word;
    var num = parseInt(req.params.number);
    console.log("repeat " + word + " x "+ num + " request made");
    var string = word + " ";
    var printString = string.repeat(num);
    res.send(printString);
    
});

app.get("*", function(req, res){
    console.log("catch all request made, route not found");
    res.send("Sorry, page not found... What are you doing with your life?");
});


//Tell Express to listen for requests (start server)
app.listen(process.env.PORT, process.env.IP, function(){
    console.log("Server has Started, Listing for Requests...");
});