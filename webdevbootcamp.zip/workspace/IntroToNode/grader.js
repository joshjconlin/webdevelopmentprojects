function average(arr){
    var num = 0;
    for(var i = 0; i<arr.length;i++){
        num += arr[i];
    }
    console.log(Math.round(num/arr.length));
    return Math.round(num/arr.length);
}
var scores = [90, 98, 89, 100, 100, 86, 94];
var scores2 = [40, 65, 77, 82, 80, 54, 73, 63, 95, 49];
average(scores);
average(scores2);