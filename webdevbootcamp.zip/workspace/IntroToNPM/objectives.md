#Intro to NPM

*Define NPM
*Explain why NPM is Awesome
*Intro the packages we will end up using



#Installing and Using Packages

*Use 'npm install' to install a packages
*Use 'require()' to include a package

