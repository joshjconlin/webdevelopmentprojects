var express = require("express");
var app = express();

//routes
// "/" => "Hi there!"

app.get("/", function(req, res){
    console.log("'someone made a home / request'");
    res.send("Hi There!");
});
// "/bye" => "Goodbye"
app.get("/bye", function(req,res){
    console.log("'Someone made a request to /bye!'");    
    res.send("Goodbye!"); 
});
// "/dog" => "Meow!"
app.get("/dog", function(req, res) {
    console.log("'Someone made a request to /dog!'");
    res.send("MEOW!!!");    
});


// using a ':' after a / directory name, allows for use of
// patterns & variables rather than specifying every possible
//directory
app.get("/r/:subredditName", function(req, res){
    var subreddit = req.params.subredditName.toUpperCase();
    console.log(subreddit + " subreddit accessed");
    res.send("Welcome to a " + subreddit + " Subreddit");
});

app.get("/r/:subredditName/:comments/:id/:title/", function(req, res){
    var subreddit = req.params.subredditName.toUpperCase();
    console.log("A " +subreddit + " subreddit request has been made");
    res.send("Welcome to the " + subreddit + " Subreddit");
});


app.get("*",function(req, res){
    console.log("someone made an invalid /request");
    res.send("You are a star!!! LOL JK THERE'S NOTHING HERE, TRY A VALID PATH!");
});


// Tell Express to listen for requests (start server)
app.listen(process.env.PORT, process.env.IP, function(){
    console.log("Server has Started, Listing for Requests...");
});