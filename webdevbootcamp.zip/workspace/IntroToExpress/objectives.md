#Introduction to Express

*What is a framework? How is it different from a library?
*What is Express?
*Why are we using Express?