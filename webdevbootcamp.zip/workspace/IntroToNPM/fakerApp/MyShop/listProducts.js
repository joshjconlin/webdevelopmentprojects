// read faker docs figure out how it works
// use faker to print out 10 random product names and prices
//run node file and make sure it works

var faker = require('faker');
var productPrices = [];
function fakerProduct(){
for(var i = 0; i <10; i++){
    var product = {
        name: faker.commerce.productName(),
        price: faker.commerce.price()
    }
    productPrices.push(product);
}
return productPrices;
}

function myShop(arr){
    console.log('======================');
    console.log('  WELCOME TO MY SHOP! ');
    console.log('======================');
    for(var i = 0; i<arr.length; i++){
        console.log(arr[i].name + ' - $' + arr[i].price);
    }
}

myShop(fakerProduct());