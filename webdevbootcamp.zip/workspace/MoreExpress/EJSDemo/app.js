var express = require("express");
var app = express();

app.use(express.static("public"));
app.set("view engine", "ejs");

app.get("/", function(req, res){
    console.log("Home Page Request Made!!");
    res.render("home");
});

app.get("/fallinlovewith/:thing", function(req, res){
    var thing = req.params.thing;
    
    console.log("love.ejs requested for object: " + thing);
    res.render("love", {thingVar: thing});
});

app.get("/posts", function(req, res){
   var posts = [
        {title: "Puppies", author: "Susy"},
        {title: "My adorable pet bunny", author: "Charlie"},
        {title: "Can you believe this pomsky?", author: "Josh"},
       ];
    console.log("posts.ejs requested");
    res.render("posts", {posts: posts});
});

//Tell Express to listen for requests (start server)
app.listen(process.env.PORT, process.env.IP, function(){
   console.log("Server has Started, Listening for Requests on ");
   console.log(process.env.PORT + " " + process.env.IP + " ...");
});
